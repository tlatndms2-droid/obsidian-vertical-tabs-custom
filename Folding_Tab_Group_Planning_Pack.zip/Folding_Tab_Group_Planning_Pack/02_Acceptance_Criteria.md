# Folding Tab Group Mode — Acceptance Criteria

## 모드
1. Tab Group `∨` 메뉴에서 체크형 토글 가능.
2. 최초 ON 시 현재 묶음 모두 펼침.
3. OFF 시 Folding UI 제거 및 일반 레이아웃 복귀.
4. OFF 후 다시 ON 시 기존 Folding 상태 복원.
5. 모든 Window에서 Mode ON/OFF 연동.
6. 새 Window는 현재 Mode 상태를 따름.

## 세로 Bar
7. Mode ON 시 모든 Folding 묶음 왼쪽에 아주 얇은 Bar 표시.
8. 펼침/접힘 Bar 폭 동일.
9. 아이콘 없이 위→아래 세로 그룹명 표시.
10. 긴 그룹명 말줄임.
11. 활성 Tab Group이 포함된 Bar는 살짝 강조.

## 접기/펼치기
12. Bar 좌클릭으로 해당 묶음만 접힘.
13. 접힌 Bar 좌클릭으로 해당 묶음만 펼침.
14. 다른 묶음 상태는 자동 변경되지 않음.
15. 접힌 묶음은 Bar만 남고 내부 탭/콘텐츠는 숨김.
16. 확보된 공간은 다른 펼쳐진 영역이 사용.
17. 마지막 하나의 펼쳐진 Folding 묶음은 접히지 않음.
18. 마지막 묶음 접기 시도는 무반응/알림 없음.
19. Tab Group 하나뿐인 Window에서도 Bar는 표시되나 접히지 않음.

## 복합 분할 / 공유 Bar
20. 최상위 좌우 영역 하나 = Folding 묶음 하나.
21. 내부 위/아래·좌우 복합 Tab Group은 공유 Bar 사용.
22. 실제 Tab Group은 병합되지 않음.
23. 공유 Bar 클릭 시 전체 함께 접기/펼치기.
24. 다시 펼치면 기존 내부 분할 구조 유지.
25. 공유 Bar 이름은 실제 화면 배치 순서대로 표시.
26. 공유 Bar 펼침 시 마지막 활성 Tab Group/탭 복원.

## 이름
27. Bar 이름은 Vertical Tabs 실제 그룹명과 동일.
28. Vertical Tabs 이름 변경 → Bar 반영.
29. Bar 이름 변경 → Vertical Tabs 반영.
30. 단일 Bar 우클릭 메뉴에는 이름 변경만.
31. 공유 Bar 우클릭 → 이름 변경 → 실제 Tab Group 선택.
32. 공유 Bar 전용 별도 이름 없음.

## 드래그 / 레이아웃
33. Bar 드래그 시 Folding 묶음 전체가 내부 레이아웃 유지한 채 이동.
34. 접힌 묶음도 Bar 드래그 이동 가능.
35. 개별 탭은 기존 Obsidian 방식으로 이동/분할 가능.
36. 새 Tab Group은 기본 펼침 상태.
37. Workspace 구조 변경 시 Folding 묶음 자동 재계산.

## 자동 펼침 / 포커스
38. 접힌 묶음 안의 탭이 Vertical Tabs에서 선택되면 자동 펼침.
39. Vertical Tabs에서 그룹 자체가 활성화돼도 자동 펼침.
40. 검색/내부 링크/명령 등 다른 경로로 탭 활성화돼도 자동 펼침.
41. 자동 펼침 후 해당 Tab Group/탭 포커스.
42. 사용자가 다시 직접 접기 전까지 펼침 유지.

## Stack tabs / Obsidian 기본 기능
43. Stack tabs와 Folding 동시 사용 가능.
44. Folding 동작이 내부 Stack tabs 상태를 변경하지 않음.
45. 탭 콘텐츠/파일/Canvas 상태는 Folding이 직접 제어하지 않음.

## 지속성
46. 일반 앱 재시작 후 Mode 상태 복원.
47. 일반 앱 재시작 후 Folding 상태 복원.
48. 플러그인 비활성화/수동 리로드 시 Folding 상태 초기화.
49. 리셋 시 일반 레이아웃 복귀.

## 플랫폼
50. Desktop에서 동작.
51. Mobile은 현재 완료 범위에서 제외.
