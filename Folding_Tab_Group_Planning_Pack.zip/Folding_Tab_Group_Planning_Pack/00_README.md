# Folding Tab Group Planning Pack

기존 Vertical Tabs 커스텀 플러그인에 `Folding Tab Group Mode` 기능을 추가하기 위한 개발 기획 패키지입니다.

## 구성
- 01_Final_Planning_Document.md
- 02_Acceptance_Criteria.md
- 03_Decision_Log.md
- 04_UI_Interaction_Spec.md
- 05_Validation_Report.md
- references/

## 핵심 한 줄
Obsidian Workspace의 실제 Tab Group 구조를 유지하면서, 최상위 좌우 영역 단위로 Folding 묶음을 만들고 세로 Bar로 접기/펼치기·이동·이름 관리를 제공한다.

## 현재 상태
- Core Process 0~7단계 완료
- 8단계 전체 검증 완료
- Critical / High 문제 없음
- P0 / P1 미결정 없음
- Codex 구현 착수 가능
