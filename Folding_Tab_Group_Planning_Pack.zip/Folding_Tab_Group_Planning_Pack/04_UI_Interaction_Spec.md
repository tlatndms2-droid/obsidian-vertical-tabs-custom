# UI / Interaction Spec

## Mode 진입점
`Tab Group 우측 상단 ∨ → Folding Tab Group Mode`

- OFF: 체크 없음
- ON: 체크 표시

## Folding Bar
- Folding 묶음 왼쪽
- 아주 얇은 폭
- 펼침/접힘 동일 폭
- 위→아래 세로 글자
- 아이콘 없음
- 긴 이름 말줄임
- 활성 묶음 약한 강조
- 펼친 상태에서도 Bar 유지

## Bar 조작
| 입력 | 동작 |
|---|---|
| 좌클릭 | 해당 Folding 묶음 접기/펼치기 |
| 우클릭 | 이름 변경 메뉴 |
| 드래그 | 해당 Folding 묶음 전체 이동 |
| 더블클릭 | 없음 |

## 이름 변경
단일 Bar:
- `이름 변경` → 실제 Vertical Tabs 그룹명 수정

공유 Bar:
- `이름 변경` → 포함된 실제 Tab Group 목록 → 수정할 그룹 선택

## 공유 Bar 표시
- 포함된 실제 Tab Group 이름 모두 표시
- 실제 화면 배치 순서 사용
- 별도 공유 Bar 이름 없음

## 접힘 표시
접힘:
- Bar만 남김
- 내부 Tab Group/탭 헤더/콘텐츠 숨김

펼침:
- Bar + 기존 내부 레이아웃 표시

## 포커스
Bar로 펼칠 때:
- 마지막 활성 Tab Group 복원
- 그 안의 마지막 활성 탭 포커스

접힌 묶음 내부 탭이 외부에서 활성화될 때:
- 묶음 전체 자동 펼침
- 해당 Tab Group/탭 포커스

## 드래그
공유 Bar:
- 내부 레이아웃 전체를 하나의 Folding 묶음으로 이동

개별 탭:
- 기존 Obsidian 탭 드래그/분할 동작 유지
