# Folding Tab Group Mode — 최종 개발 기획서

## 1. 프로젝트 개요
- 개발 유형: 기존 Obsidian Vertical Tabs 커스텀 플러그인의 기능 추가
- 기능명: Folding Tab Group Mode
- 플랫폼: Desktop Obsidian 전용
- 한 줄 정의: Obsidian Workspace의 Tab Group들을 세로 Bar 기반으로 접고 펼칠 수 있게 하고, 복합 분할 구조에서는 최상위 좌우 영역 단위로 Folding 묶음을 구성하는 기능
- 핵심 목적: 여러 Tab Group을 동시에 유지하면서 필요하지 않은 영역을 최소 폭으로 접어 작업 공간을 효율적으로 사용한다.

## 2. 문제와 개발 목적
여러 Tab Group을 동시에 사용하는 Workspace에서는 화면이 쉽게 좁아진다. 기존 Stacked Tabs는 개별 탭 표시 방식이므로 Tab Group 전체를 접어 공간을 확보하는 기능과는 목적이 다르다.

목표:
- 실제 Tab Group 구조 유지
- 필요한 작업 영역만 펼치고 나머지는 세로 Bar 수준으로 접기
- 기존 Vertical Tabs 및 Obsidian 탭 이동/분할 흐름 유지
- 복합 분할도 현재 Workspace 구조 기준으로 자동 Folding 묶음 구성

## 3. 사용자 및 환경
- Desktop Obsidian
- Vertical Tabs 커스텀 플러그인 사용자
- 다수 Tab Group/복합 분할 Workspace
- Mobile 제외
- Obsidian 기본 Stack tabs와 독립 사용

## 4. 핵심 요구사항
1. Tab Group 메뉴에서 Folding Tab Group Mode를 켜고 끌 수 있어야 한다.
2. Mode ON 시 Folding 묶음마다 아주 얇은 세로 Bar가 표시되어야 한다.
3. 각 Folding 묶음은 독립적으로 접기/펼치기 가능해야 한다.
4. 마지막 하나의 펼쳐진 Folding 묶음은 접을 수 없어야 한다.
5. 복합 분할은 실제 Tab Group을 병합하지 않고 Folding UI에서만 하나의 묶음으로 취급해야 한다.
6. 접힌 영역의 빈 공간은 다른 펼쳐진 영역이 기존 Obsidian 레이아웃 방식에 따라 사용해야 한다.
7. 접힌 묶음 내부 탭이 어떤 경로로든 활성화되면 묶음 전체가 자동으로 펼쳐져야 한다.
8. 그룹 이름은 Vertical Tabs의 기존 그룹 이름과 양방향 연동되어야 한다.
9. Folding Mode 상태는 모든 Obsidian Window에서 연동되어야 한다.
10. 일반 Obsidian 재시작 후 Folding Mode와 접힘/펼침 상태를 복원해야 한다.

## 5. 대표 사용 시나리오
### A. Folding Mode 시작
Tab Group 우측 상단 `∨` 메뉴 → `Folding Tab Group Mode` 체크 → 모든 Folding 묶음 왼쪽에 Bar 표시.

### B. 접기/펼치기
Bar 좌클릭 → 해당 묶음만 접힘 → Bar만 남음 → 다시 클릭 → 기존 내부 분할 상태 그대로 펼쳐짐.

### C. 복합 분할
오른쪽 큰 영역 내부가 `B/C` 좌우 분할 + 아래 `D`라면 B/C/D는 하나의 Folding 묶음. 실제 Tab Group은 별개로 유지.

### D. 개별 탭 분리
Tab Group C의 C1 탭을 기존 Obsidian 방식으로 옆으로 드래그 → 새 Tab Group 생성 → 실제 Workspace 구조 기준으로 Folding 묶음 자동 재계산.

### E. 접힌 묶음 탭 활성화
접힌 B/C/D 묶음 안의 탭이 Vertical Tabs, 검색, 내부 링크, 명령 등으로 활성화 → B/C/D 전체 펼침 → 해당 Tab Group/탭 포커스.

## 6. 기능 구조
### Folding Mode
- Tab Group `∨` 메뉴 내 체크형 토글
- 모든 Window에서 ON/OFF 연동
- OFF 시 일반 레이아웃 복귀
- 다시 ON 시 기존 Folding 상태 복원

### Folding Bar
- 아주 얇은 고정 폭
- 펼침/접힘 모두 표시
- 위→아래 세로 글자
- 아이콘 없음
- 긴 이름 말줄임
- 활성 묶음 약한 강조

### Folding 묶음
- 최상위 좌우 영역 하나 = Folding 묶음 하나
- 내부 위/아래·좌우 복합 분할은 공유 Bar 사용
- 실제 Tab Group 병합 없음
- Workspace 구조 변경 시 자동 재계산

### 상태 복원
- 최초 Mode ON: 모두 펼침
- Mode ON 중 새 Tab Group: 기본 펼침
- 일반 앱 재시작: 상태 복원
- 플러그인 비활성화/수동 리로드: Folding 상태 리셋

## 7. UI 및 사용자 조작
### Tab Group 메뉴
`Tab Group 우측 상단 ∨ → Folding Tab Group Mode`
- OFF: 체크 없음
- ON: 체크 표시

### 세로 Bar
- 좌클릭: 접기/펼치기
- 우클릭: 이름 변경
- 드래그: Folding 묶음 전체 이동
- 더블클릭: 없음

### 이름 변경
단일 Bar: 해당 그룹명 편집.
공유 Bar: `이름 변경` → 실제 Tab Group 목록 → 선택한 그룹만 편집.
공유 Bar 전용 이름 없음.

## 8. 데이터·상태·저장
- Mode 상태: 모든 Window 공유
- Folding 상태: 묶음 단위
- Bar로 펼치면 접기 직전 마지막 활성 Tab Group/탭 복원
- 접힌 묶음 내부 탭이 활성화되면 자동 펼침
- 자동 펼침 후 사용자가 직접 접기 전까지 유지

플러그인이 직접 관리하지 않는 것:
- 탭 콘텐츠
- Markdown/File 갱신
- Canvas 상태
- Stack tabs 내부 동작
- 기타 Obsidian 내부 탭 상태

## 9. 기능 관계
- Vertical Tabs 그룹명 ↔ Folding Bar 그룹명: 양방향 동일 데이터
- Workspace 실제 분할 구조 → Folding 묶음 자동 구성
- 개별 탭 이동 → Tab Group 구조 변경 → Folding 묶음 재계산
- Folding은 Tab Group 구조를 대체하거나 병합하지 않음

## 10. 예외·복구
- 마지막 펼친 묶음 접기: 무반응, 알림 없음
- Tab Group 하나뿐인 Window: Bar 표시, 접기는 안 됨
- 플러그인 비활성화/수동 리로드: Folding UI 제거, Mode OFF, Folding 상태 초기화
- 일반 앱 재시작: Mode 및 Folding 상태 복원

## 11. 제약·호환성
- Desktop 전용
- Mobile 제외
- Stack tabs와 독립 사용
- 기존 탭 이동/분할 유지
- 정확한 DOM/API/상태 추적 방식은 Codex가 현재 코드/버전을 보고 결정
- Bar px 폭, 색상, 테두리 등 미세 시각 수치는 구현 단계 조정

## 12. 개발 범위
### 반드시 포함
- Folding Mode
- 세로 Bar
- 독립 접기/펼치기
- 복합 분할 공유 Bar
- 자동 묶음 계산
- 그룹명 연동/이름 변경
- 활성 Bar 강조
- Bar 드래그
- 기존 개별 탭 이동/분할 유지
- 접힌 묶음 탭 활성화 시 자동 펼침
- Window Mode 연동
- 일반 재시작 복원
- Stack tabs와 독립 동작

### 명시적 제외
- Mobile
- Folding 묶음 수동 편집 UI
- Folding 전용 별도 그룹명
- 별도 탭 이동 시스템
- 내부 탭 콘텐츠/파일 상태 제어
- 더블클릭 기능
- 우클릭 메뉴의 접기/펼치기 항목

## 13. 미결정/구현 재량
P0/P1 미결정 없음.

구현 재량:
- Bar 정확한 px 폭
- 활성 Bar의 정확한 스타일
- 그룹명이 매우 많을 때 세부 렌더링
- Obsidian Workspace/DOM/API에서 Folding 묶음 추적 방식
